// script.js

const bookBtn = document.getElementById('book-btn');
const buyBtn = document.getElementById('buy-btn');
const priceElement = document.getElementById('price');

bookBtn.addEventListener('click', () => {
    // Book now functionality
    alert('Booked successfully!');
});

buyBtn.addEventListener('click', () => {
    // Buy now functionality
    alert('Payment gateway will be integrated here.');
});